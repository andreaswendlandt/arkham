<?php
        $host="localhost";
        $user="root";
        $password="egal";
        $database="gb";
?>

