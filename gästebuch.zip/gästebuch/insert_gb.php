<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
<head>
<title>G&auml;stebuch</title>
<link rel="stylesheet" type="text/css" href="form.css">
</head>
<body>
<?php
//Datei mit den Zugangsdaten einbinden
include("credentials.php");
//Verbindung zur Datenbank aufbauen
$conn = mysql_connect("$host","$user", "$password") 
   or die ("Keine Verbindung m&ouml;glich");
//Datenbank auswählen
mysql_select_db("$database") 
   or die ("Die Datenbank existiert nicht");
//Variablen mit Werten befüllen
$name = $_POST["name"];
//eventuelle Sonderzeichen konvertieren
$name = htmlentities($name);
$email = $_POST["email"];
$content = $_POST["inhalt"];
//eventuelle Sonderzeichen konvertieren
$content = htmlentities($content);
$date = time();
//Prüfen ob die Variablen auch befüllt wurden, d.h. wurden alle Felder des Formulars ausgefüllt
if($name == "" OR $content == "" OR $email == "")
    {
   echo "Bitte ALLE Felder ausf&uuml;llen<br> <a href=\"formular.html\">Zur&uuml;ck zum Formular</a>";
   exit();
    }
//dann die Werte in die Datenbank eintragen 
$entry = "INSERT INTO gaestebuch (datum, name, email, inhalt) VALUES ('$date', '$name', '$email', '$content')";
$insert_into_db = mysql_query($entry);
//Prüfen ob das Eintragen geklappt hat und eine Rückmeldung geben 
if($insert_into_db == true)
   {
   echo "Beitrag erfolgreich gespeichert. ";
   }
else
   {
   echo "Fehler beim Speichern, bitte versuchen Sie es erneut";
   }
echo "<br> <a href='index.php'>Zur&uuml;ck zum G&auml;stebuch</a>";
?> 
</body>
</html>

